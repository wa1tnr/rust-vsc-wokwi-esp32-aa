{
  "version": 1,
  "author": "Sergio Gasquez Arcos",
  "editor": "wokwi",
  "parts": [
    {
      "type": "board-esp32-devkit-c-v4",
      "id": "esp",
      "top": -28.8,
      "left": -4.76,
      "attrs": { "builder": "rust-nostd-esp" }
    },
    {
      "type": "wokwi-resistor",
      "id": "r1",
      "top": 109.55,
      "left": 115.2,
      "attrs": { "value": "1000" }
    },
    {
      "type": "wokwi-led",
      "id": "led1",
      "top": 15.6,
      "left": 157.4,
      "attrs": { "color": "red", "flip": "" }
    }
  ],
  "connections": [
    [ "esp:TX", "$serialMonitor:RX", "", [] ],
    [ "esp:RX", "$serialMonitor:TX", "", [] ],
    [ "esp:GND.3", "led1:C", "black", [ "h76.8", "v-9.6" ] ],
    [ "led1:A", "r1:2", "green", [ "v0" ] ],
    [ "esp:4", "r1:1", "green", [ "h0" ] ]
  ],
  "serialMonitor": { "display": "terminal" },
  "dependencies": {}
}