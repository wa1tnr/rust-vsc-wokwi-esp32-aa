

newest:


    [ "4-5-15-17-18-19-20-21-22-23-25-26"]


    { "type": "wokwi-led", "id": "led15", "top": -90, "left": 80.6, "attrs": { "color": "blue" } },

    { "type": "wokwi-led", "id": "led17", "top": -90, "left": 119, "attrs": { "color": "purple" } },
    { "type": "wokwi-led", "id": "led18", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    {
      "type": "wokwi-led",
      "id": "led19",
      "top": -90,
      "left": 186.2,
      "attrs": { "color": "white" }
    },

    { "type": "wokwi-led", "id": "led21", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    { "type": "wokwi-led", "id": "led22", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    { "type": "wokwi-led", "id": "led23", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    { "type": "wokwi-led", "id": "led25", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    { "type": "wokwi-led", "id": "led26", "top": -90, "left": 147.8, "attrs": { "color": "grey" } },
    {
      "type": "wokwi-led",
      "id": "led20",
      "top": -32.4,
      "left": -169,
      "attrs": { "color": "black" }
    }





older:

   [ "led1:C", "r1:1", "black", [ "v19.2", "h-47.6" ] ],
    [ "esp:GND.3", "r1:2", "black", [ "v-19.2", "h-48" ] ],
    [ "led1:A", "esp:5", "green", [ "v19.2", "h19.2" ] ],
    [ "led2:C", "led11:C", "green", [ "v19.2", "h38.8" ] ]




